/* NGi-provider
{
  "api_version": 1,
  "id": "plugin_aventertainments",
  "name": "AV Entertainments",
  "version": "1.4.1",
  "description": "AV Entertainments（aventertainments.com）日本无码 DVD 源（如果无法使用，请尝试更换代理）",
  "actor_gender": "F",
  "base_url": "https://www.aventertainments.com",
  "categories": ["jav_uncensored"]
}
*/

// ===== 常量 =====
const FALLBACK_BASE = 'https://www.aventertainments.com';
const SEARCH_PATH = '/dvd/search?lang=2&cat=29&keyword=';
const PAGE_PARAMS = '&searchby=keyword&page=';
const CODE_PARAMS = '&searchby=code&page=';
const MAX_PAGES = 2;      // 关键词搜索最多翻 2 页
const MAX_VERIFY = 3;     // 标题模糊匹配时最多核对 3 个详情页
const OUTLINE_LIMIT = 2000;
const WALL_PATTERN = /g-recaptcha|VerifyBot|verifybot|h-captcha|cf-challenge|just a moment|turnstile/i;

// ===== 通用工具 =====
const clean = (value) => String(value === null || value === undefined ? '' : value).replace(/\s+/g, ' ').trim();
const keyOf = (value) => clean(value).toUpperCase().replace(/[^0-9A-Z]/g, '');

const textOf = (node) => (node && typeof node.text === 'function' ? clean(node.text()) : '');

const attrOf = (node, name) => {
  if (!node || typeof node.attr !== 'function') return '';
  const value = node.attr(name);
  return value === null || value === undefined ? '' : clean(value);
};

// 去掉标题尾部的「 : 演员名」
const stripActors = (rawTitle, actors) => {
  const splitAt = rawTitle.lastIndexOf(' : ');
  if (splitAt > 0) {
    const tail = rawTitle.slice(splitAt + 3).trim();
    if (tail && actors.some((name) => name === tail || tail.indexOf(name) >= 0)) {
      return rawTitle.slice(0, splitAt).trim();
    }
  }
  return rawTitle;
};

// 页面的 og:image（站点的正面封面 = 竖版海报）
const ogImageOf = (page) => {
  if (!page || typeof page.select !== 'function') return '';
  let meta = null;
  try {
    meta = page.select('meta[property="og:image"]');
  } catch (error) {
    return '';
  }
  return clean(attrOf(meta, 'content'));
};

// 页面的 og:description（去掉站点自带的宣传尾巴）
const ogDescriptionOf = (page) => {
  if (!page || typeof page.select !== 'function') return '';
  let meta = null;
  try {
    meta = page.select('meta[property="og:description"]');
  } catch (error) {
    return '';
  }
  const text = clean(attrOf(meta, 'content'));
  if (!text) return '';
  return clean(text.replace(/\s*[,|]\s*(?:Av|AV)\s*Entertainment[\s\S]*$/i, ''));
};

// 详情页内嵌的预告片地址（JSON-LD contentUrl / HLS_URL 变量 / video 标签）-> 绝对地址或空串
const trailerFromHtml = (html) => {
  const text = String(html || '');
  const patterns = [
    /"contentUrl"\s*:\s*"([^"]+?\.(?:m3u8|mp4)(?:\?[^"]*)?)"/i,
    /HLS_URL\s*=\s*'([^']+?\.(?:m3u8|mp4)[^']*)'/i,
    /HLS_URL\s*=\s*"([^"]+?\.(?:m3u8|mp4)[^"]*)"/i,
    /<video[^>]+src="([^"]+?\.(?:m3u8|mp4)[^"]*)"/i,
    /<source[^>]+src="([^"]+?\.(?:m3u8|mp4)[^"]*)"/i,
  ];
  for (const pattern of patterns) {
    const matched = pattern.exec(text);
    if (matched && matched[1]) return clean(matched[1].replace(/\\\//g, '/'));
  }
  return '';
};

// DVD1MXX-11 / dvd1mxx-113 -> MXX-11 / MXX-113
const numberFromCode = (raw) => {
  const value = clean(raw).toUpperCase();
  if (!value) return '';
  return value.replace(/^(?:DVD|BD|VOD|PPV)[0-9]*/, '');
};

// .../cart/addcart?lang=2&cat=29&item_no=DVD1MXX-11&qty=1 -> DVD1MXX-11
const itemNoFromHref = (href) => {
  const matched = /[?&]item_no=([^&]+)/i.exec(String(href || ''));
  return matched ? decodeURIComponent(matched[1]) : '';
};

// .../jacket_images/dvd1mxx-11.webp -> MXX-11
const numberFromImage = (src) => {
  const matched = /([^/?#]+)\.(?:webp|jpe?g|png)(?:[?#]|$)/i.exec(String(src || ''));
  return matched ? numberFromCode(matched[1]) : '';
};

// 标题里的 MXX 11 -> MXX11（只用于挑选待核对候选，不用于最终匹配）
const codesInTitle = (title) => {
  const found = [];
  const pattern = /([A-Za-z]{2,6})[\s\-_.]*([0-9]{1,5})(?![0-9])/g;
  let matched;
  while ((matched = pattern.exec(String(title || ''))) !== null) {
    found.push(keyOf(matched[1] + matched[2]));
  }
  return found;
};

// ===== 地址解析：一切请求都按 ctx.baseUrl 拼，来源地址可指向任一中继 =====
const baseOf = (ctx) => {
  const value = clean(ctx && ctx.baseUrl ? ctx.baseUrl : '').replace(/\/+$/, '');
  return value || FALLBACK_BASE;
};

const pathOf = (value) => {
  const text = clean(value);
  if (!text) return '';
  if (/^https?:\/\//i.test(text)) return text.replace(/^https?:\/\/[^/]+/i, '');
  return text.charAt(0) === '/' ? text : `/${text}`;
};

const absoluteOf = (ctx, value) => {
  const path = pathOf(value);
  return path ? `${baseOf(ctx)}${path}` : '';
};

// ===== 详情页信息行 =====
const VALUE_SELECTORS = ['.tag-title', '.value-category', '.value'];

const valueNodeOf = (row) => {
  for (let i = 0; i < VALUE_SELECTORS.length; i += 1) {
    const node = row.select(VALUE_SELECTORS[i]);
    if (textOf(node)) return node;
  }
  return null;
};

const infoMap = (page) => {
  const map = {};
  for (const row of page.selectAll('.product-info-block-rev .single-info')) {
    const label = clean(textOf(row.select('.title'))).replace(/\s+/g, '');
    if (!label) continue;
    if (!map[label]) map[label] = valueNodeOf(row);
  }
  return map;
};

const listFromNode = (node) => {
  if (!node) return [];
  const values = [];
  for (const anchor of node.selectAll('a')) {
    const value = textOf(anchor);
    if (value) values.push(value);
  }
  if (values.length) return values;
  const text = textOf(node);
  return text ? [text] : [];
};

const LABELS = {
  number: ['商品番号', 'Item#', 'ItemNo', 'ItemNumber', 'Product#', 'ProductNumber', '番号'],
  actors: ['主演女優', '出演者', 'Starring', 'Actress', 'Actresses'],
  studio: ['スタジオ', 'メーカー', 'Studio', 'Maker'],
  publisher: ['レーベル', 'Label', 'Publisher'],
  director: ['監督', 'Director'],
  series: ['シリーズ', 'Series'],
  tags: ['カテゴリ', 'ジャンル', 'Category', 'Genre'],
  release: ['発売日', '発売', 'Date', 'ReleaseDate', 'Released'],
  runtime: ['収録時間', '再生時間', 'PlayTime', 'Runtime', 'Duration'],
};

const pickLabel = (map, names) => {
  for (let i = 0; i < names.length; i += 1) {
    if (map[names[i]]) return map[names[i]];
  }
  return null;
};

const parseRelease = (raw) => {
  const text = clean(raw);
  if (!text) return '';
  let matched = /([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})/.exec(text);
  if (matched) {
    return `${matched[1]}-${matched[2].padStart(2, '0')}-${matched[3].padStart(2, '0')}`;
  }
  matched = /([0-9]{1,2})[/.-]([0-9]{1,2})[/.-]([0-9]{4})/.exec(text);
  if (matched) {
    const month = Number(matched[1]);
    const day = Number(matched[2]);
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return `${matched[3]}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
  }
  return '';
};

const parseRuntime = (raw) => {
  const matched = /([0-9]{1,4})/.exec(clean(raw));
  if (!matched) return 0;
  const minutes = Number(matched[1]);
  return minutes > 0 && minutes < 1000 ? minutes : 0;
};

// ===== 搜索页解析 =====
const cardsOf = (page) => {
  let cards = page.selectAll('.shop-product-wrap .single-slider-product');
  if (!cards || cards.length === 0) cards = page.selectAll('.single-slider-product');
  return cards || [];
};

const cardInfo = (card) => {
  const link = card.select('.product-title a');
  const url = attrOf(link, 'href');
  if (!url) return null;
  const title = textOf(link);
  const imageSrc = attrOf(card.select('.single-slider-product__image img'), 'src');
  const cartHref = attrOf(card.select('.cart-icon a'), 'href');
  const fromItemNo = numberFromCode(itemNoFromHref(cartHref));
  const fromImage = numberFromImage(imageSrc);
  return {
    url,
    title,
    number: fromItemNo || fromImage,
    codes: [keyOf(fromItemNo), keyOf(fromImage)],
  };
};

const WALL_MESSAGE = [
  '站点把 /dvd/search 跳转到了人工验证页 。',
].join('');

// ===== 主逻辑 =====
export default {
  async search(ctx, number) {
    const query = clean(number);
    if (!query) return [];
    const wanted = keyOf(query);
    const encoded = encodeURIComponent(query);

    const attempts = [];
    for (let pageNo = 1; pageNo <= MAX_PAGES; pageNo += 1) {
      attempts.push(`${SEARCH_PATH}${encoded}${PAGE_PARAMS}${pageNo}`);
    }
    attempts.push(`${SEARCH_PATH}${encoded}${CODE_PARAMS}1`);

    const exact = [];
    const fuzzy = [];
    let walled = 0;
    let emptyListed = 0;
    let cardsSeen = 0;

    for (const path of attempts) {
      let html = '';
      try {
        html = await ctx.http.get(absoluteOf(ctx, path));
      } catch (error) {
        ctx.log(`搜索请求失败：${path}`);
        continue;
      }
      if (typeof html !== 'string' || html.length === 0) continue;

      const page = ctx.html.parse(html);
      const cards = cardsOf(page);
      if (cards.length === 0) {
        if (WALL_PATTERN.test(html)) {
          walled += 1;
        } else if (/\(0\s*件\)/.test(html)) {
          emptyListed += 1;
        }
        continue;
      }

      cardsSeen += cards.length;
      for (const card of cards) {
        const info = cardInfo(card);
        if (!info) continue;
        if (info.codes.indexOf(wanted) >= 0) {
          exact.push(info);
        } else if (codesInTitle(info.title).indexOf(wanted) >= 0) {
          fuzzy.push(info);
        }
      }
      if (exact.length > 0) break;
    }

    if (exact.length > 0) {
      ctx.log(`搜索命中 ${exact.length} 个候选（按商品编号精确匹配）`);
      return exact.map((item) => ({ number: item.number, url: absoluteOf(ctx, item.url) }));
    }

    if (cardsSeen === 0) {
      if (walled > 0) throw new Error(WALL_MESSAGE);
      if (emptyListed > 0) return [];
      throw new Error('搜索页没有返回任何商品卡片，可能被站点拦截或页面结构已变化。');
    }

    if (fuzzy.length === 0) {
      ctx.log(`搜索页有结果（${cardsSeen} 张卡片），但没有与 ${query} 对应的商品编号`);
      return [];
    }

    // 只有标题里出现番号时，逐个打开详情页核对「商品番号」
    const verified = [];
    for (let i = 0; i < fuzzy.length && i < MAX_VERIFY; i += 1) {
      const candidate = fuzzy[i];
      const candidateUrl = absoluteOf(ctx, candidate.url);
      try {
        const detailPage = ctx.html.parse(await ctx.http.get(candidateUrl));
        const numberText = textOf(pickLabel(infoMap(detailPage), LABELS.number));
        if (keyOf(numberText) === wanted) {
          verified.push({ number: numberText, url: candidateUrl });
          break;
        }
      } catch (error) {
        ctx.log(`核对候选详情失败：${candidateUrl}`);
      }
    }

    if (verified.length === 0) {
      ctx.log(`候选详情页中的商品番号均与 ${query} 不一致`);
    }
    return verified;
  },

  async detail(ctx, url) {
    // 只用日文页面，一次 HTTP 请求
    const target = absoluteOf(ctx, url);
    const html = await ctx.http.get(target);
    const page = ctx.html.parse(html);
    const info = infoMap(page);

    const actors = listFromNode(pickLabel(info, LABELS.actors));
    const rawTitle = textOf(page.select('.section-title h3')) || textOf(page.select('.section-title h2'));
    const title = stripActors(rawTitle, actors);
    if (!title) throw new Error('详情页缺少标题，站点结构可能已变化');

    const links = [];
    for (const node of page.selectAll('a.lightbox')) {
      const href = attrOf(node, 'href');
      if (href && links.indexOf(href) < 0) links.push(href);
    }
    const jacket = links.find((item) => item.indexOf('/jacket_images/') >= 0) || '';
    const bigcover = links.find((item) => item.indexOf('/bigcover/') >= 0) || '';

    let number = textOf(pickLabel(info, LABELS.number));
    if (!number) {
      const guess = bigcover || jacket;
      if (guess) number = numberFromImage(guess);
    }
    if (!number) throw new Error('详情页缺少番号，站点结构可能已变化');

    const result = { Number: number, Title: title, OriginalTitle: title };
    if (actors.length) result.Actors = actors;

    const studio = listFromNode(pickLabel(info, LABELS.studio));
    if (studio.length) result.Studio = studio[0];
    const publisher = listFromNode(pickLabel(info, LABELS.publisher));
    if (publisher.length) result.Publisher = publisher[0];
    const director = listFromNode(pickLabel(info, LABELS.director));
    if (director.length) result.Director = director[0];
    const series = listFromNode(pickLabel(info, LABELS.series));
    if (series.length) result.Series = series[0];
    const tags = listFromNode(pickLabel(info, LABELS.tags));
    if (tags.length) result.Tags = tags;

    const release = parseRelease(textOf(pickLabel(info, LABELS.release)));
    if (release) {
      result.Release = release;
      result.Year = release.slice(0, 4);
    }
    const runtime = parseRuntime(textOf(pickLabel(info, LABELS.runtime)));
    if (runtime) result.Runtime = runtime;

    // 简介：正文 -> og:description 兜底
    let outline = clean(textOf(page.select('.product-description'))) || ogDescriptionOf(page);
    if (outline) result.Outline = outline.length > OUTLINE_LIMIT ? `${outline.slice(0, OUTLINE_LIMIT)}…` : outline;

    const ogImage = ogImageOf(page);
    const poster = ogImage || jacket || bigcover;
    if (bigcover) result.Cover = bigcover;
    if (poster) result.Poster = poster;
    if (!result.Cover && poster) result.Cover = poster;

    const stills = links.filter((item) => item.indexOf('/vodimages/screenshot/') >= 0);
    if (stills.length) result.ExtraFanart = stills;

    const trailer = trailerFromHtml(html);
    if (trailer) result.Trailer = trailer;

    ctx.log(`详情解析完成：${number}（剧照 ${stills.length} 张）`);
    return result;
  },
};
